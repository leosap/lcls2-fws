#!/usr/bin/env python

from DaqMuxV2.DaqMuxV2 import *